Build your Android app (APK) without installing anything

1. Create a free account at github.com and click New repository. Name it bharat-universal-calendar.
2. On the new repository page, click "uploading an existing file".
3. Unzip this folder on your computer. Drag EVERYTHING inside it into the page,
   including the .github folder (if it is hidden, enable "show hidden files").
4. Click Commit changes.
5. Click the Actions tab. The "Build Android APK" job starts by itself (about 5-10 minutes).
   If it does not, click it, then "Run workflow".
6. When it shows a green tick, open the run and download "bharat-universal-calendar-apk" at the bottom.
7. Unzip it. app-debug.apk is the app. Copy it to your phone, open it and allow
   "install from this source". 

This test APK is for trying the app on your own phone. Google Play needs a signed release
bundle (.aab), which is the next step once the app works.
